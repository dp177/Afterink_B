const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { startWork, stopWork } = require('../controllers/timeController');

router.post('/start', auth, startWork);
router.post('/stop', auth, stopWork);

module.exports = router;