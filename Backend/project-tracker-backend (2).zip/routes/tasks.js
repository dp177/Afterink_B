const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { createTask, updateStatus, getMyTasks } = require('../controllers/taskController');

router.post('/create', auth, role('ceo'), createTask);
router.post('/status', auth, role('freelancer', 'founding_member'), updateStatus);
router.get('/my', auth, getMyTasks);

module.exports = router;