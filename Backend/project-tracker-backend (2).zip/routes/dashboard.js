const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { freelancerStats } = require('../controllers/dashboardController');

router.get('/freelancer/:freelancerId', auth, role('ceo'), freelancerStats);

module.exports = router;