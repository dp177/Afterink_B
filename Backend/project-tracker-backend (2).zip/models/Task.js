const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  title: String,
  description: String,
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  projectId: String,
  status: { type: String, enum: ['not_started', 'in_progress', 'hold', 'done'], default: 'not_started' }
});

module.exports = mongoose.model('Task', taskSchema);