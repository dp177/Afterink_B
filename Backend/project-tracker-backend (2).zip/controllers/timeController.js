const TimeLog = require('../models/TimeLog');

exports.startWork = async (req, res) => {
  try {
    const { taskId } = req.body;
    const now = new Date();
    const date = now.toISOString().split('T')[0];

    const ongoing = await TimeLog.findOne({ taskId, userId: req.user._id, endTime: null });
    if (ongoing) return res.status(400).json({ error: 'Already working on this task' });

    const timeLog = await TimeLog.create({
      taskId,
      userId: req.user._id,
      startTime: now,
      date
    });
    res.status(201).json(timeLog);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.stopWork = async (req, res) => {
  try {
    const { taskId } = req.body;

    const log = await TimeLog.findOne({ taskId, userId: req.user._id, endTime: null });
    if (!log) return res.status(400).json({ error: 'No session to stop' });

    const end = new Date();
    const duration = Math.floor((end - log.startTime) / 1000);

    log.endTime = end;
    log.duration = duration;
    await log.save();

    res.json({ message: 'Session saved', duration });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};