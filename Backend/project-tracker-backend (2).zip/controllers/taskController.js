const Task = require('../models/Task');

exports.createTask = async (req, res) => {
  try {
    const { title, description, assignedTo, projectId } = req.body;
    const task = await Task.create({
      title,
      description,
      assignedTo,
      projectId,
      createdBy: req.user._id
    });
    res.status(201).json(task);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateStatus = async (req, res) => {
  try {
    const { taskId, status } = req.body;
    const allowed = ['not_started', 'in_progress', 'hold', 'done'];
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status' });

    const task = await Task.findByIdAndUpdate(taskId, { status }, { new: true });
    res.json(task);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getMyTasks = async (req, res) => {
  try {
    const tasks = await Task.find({ assignedTo: req.user._id });
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};