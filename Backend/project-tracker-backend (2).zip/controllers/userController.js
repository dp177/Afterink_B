const User = require('../models/User');
const bcrypt = require('bcryptjs');

exports.addUser = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    if (!['freelancer', 'founding_member'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ error: 'Email already exists' });

    const hashed = await bcrypt.hash(password, 10);
    const newUser = await User.create({ name, email, password: hashed, role });
    res.status(201).json({ message: `${role} created`, userId: newUser._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};