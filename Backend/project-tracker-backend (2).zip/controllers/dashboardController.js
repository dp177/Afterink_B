const TimeLog = require('../models/TimeLog');

exports.freelancerStats = async (req, res) => {
  try {
    const { freelancerId } = req.params;

    const logs = await TimeLog.find({ userId: freelancerId });

    let total = 0;
    let projects = new Set();
    let perDay = {};

    logs.forEach(log => {
      total += log.duration;
      if (log.taskId) projects.add(log.taskId.toString());
      perDay[log.date] = (perDay[log.date] || 0) + log.duration;
    });

    res.json({
      totalHours: (total / 3600).toFixed(2),
      totalTasks: projects.size,
      byDay: perDay
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};